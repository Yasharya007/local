//UPPER left triangular matrix
// #include <iostream>
// using namespace std;

// int main() {
//     int n;
//     cin >> n;
//     int arr[n][n];

//     // Input
//     for (int i = 0; i < n; i++)
//         for (int j = 0; j < n; j++)
//             cin >> arr[i][j];

//     // Output: Upper Left Triangular
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < n; j++) {
//             if (i + j < n)
//                 cout << arr[i][j] << " ";
//             else
//                 cout << 0 << " ";
//         }
//         cout << endl;
//     }

//     return 0;
// }
// UPPER RIGHT TRiangular
// #include <iostream>
// using namespace std;

// int main() {
//     int n;
//     cin >> n;
//     int arr[n][n];

//     // Input
//     for (int i = 0; i < n; i++)
//         for (int j = 0; j < n; j++)
//             cin >> arr[i][j];

//     // Output: Upper Right Triangular Matrix
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < n; j++) {
//             if (i <= j)
//                 cout << arr[i][j] << " ";
//             else
//                 cout << 0 << " ";
//         }
//         cout << endl;
//     }

//     return 0;
// }

// // lower roght triangular matrix
// #include <iostream>
// using namespace std;

// int main() {
//     int n;
//     cin >> n;
//     int arr[n][n];

//     // Input
//     for (int i = 0; i < n; i++)
//         for (int j = 0; j < n; j++)
//             cin >> arr[i][j];

//     // Output: Lower Right Triangular
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < n; j++) {
//             if (i + j >= n - 1)
//                 cout << arr[i][j] << " ";
//             else
//                 cout << 0 << " ";
//         }
//         cout << endl;
//     }

//     return 0;
// }
// //LOWER LEFT TRIANGULAR MATRIX
// #include <iostream>
// using namespace std;

// int main() {
//     int n;
//     cin >> n;
//     int arr[n][n];

//     // Input
//     for (int i = 0; i < n; i++)
//         for (int j = 0; j < n; j++)
//             cin >> arr[i][j];

//     // Output: Lower Left Triangular Matrix
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < n; j++) {
//             if (i >= j)
//                 cout << arr[i][j] << " ";
//             else
//                 cout << 0 << " ";
//         }
//         cout << endl;
//     }

//     return 0;
// }
// // DIAGONAL
// #include <iostream>
// using namespace std;

// int main() {
//     int n;
//     cin >> n;
//     int arr[n][n];

//     // Input the matrix
//     for (int i = 0; i < n; i++)
//         for (int j = 0; j < n; j++)
//             cin >> arr[i][j];

//     // Output: Diagonal Matrix
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < n; j++) {
//             if (i == j)
//                 cout << arr[i][j] << " ";  // Print diagonal element
//             else
//                 cout << 0 << " ";  // Print zero for off-diagonal
//         }
//         cout << endl;
//     }

//     return 0;
// }
// // TRIDIAGONAL
// #include <iostream>
// using namespace std;

// int main() {
//     int n;
//     cin >> n;
//     int arr[n][n];

//     // Input the matrix
//     for (int i = 0; i < n; i++)
//         for (int j = 0; j < n; j++)
//             cin >> arr[i][j];

//     // Output: Tridiagonal Matrix
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < n; j++) {
//             if (i == j || i == j + 1 || i == j - 1)
//                 cout << arr[i][j] << " ";  // Print diagonal and adjacent diagonals
//             else
//                 cout << 0 << " ";  // Print 0 for non-relevant elements
//         }
//         cout << endl;
//     }

//     return 0;
// }
// // ALPHA BETA BAND MATIRX
// #include <iostream>
// using namespace std;

// int main() {
//     int n, alpha, beta;
//     cin >> n >> alpha >> beta;
//     int arr[n][n];

//     // Input the matrix
//     for (int i = 0; i < n; i++)
//         for (int j = 0; j < n; j++)
//             cin >> arr[i][j];

//     // Output: Alpha-Beta Band Matrix
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < n; j++) {
//             if (i - j <= alpha && j - i <= beta)
//                 cout << arr[i][j] << " ";
//             else
//                 cout << 0 << " ";
//         }
//         cout << endl;
//     }

//     return 0;
// }

//LINKEDLIST
#include<iostream>
using namespace std;

struct node {
    int data;
    node* next;
};

// Function to insert after a given node
void insertAfter(node* prevNode, int newData) {
    if (prevNode == nullptr) {
        cout << "The previous node cannot be NULL" << endl;
        return;
    }

    node* newNode = new node;
    newNode->data = newData;
    newNode->next = prevNode->next;
    prevNode->next = newNode;
}

// Function to insert before a given node
void insertBefore(node*& head, node* nextNode, int newData) {
    if (nextNode == nullptr) {
        cout << "The next node cannot be NULL" << endl;
        return;
    }

    node* newNode = new node;
    newNode->data = newData;
    newNode->next = nextNode;

    // If the next node is the first node
    if (head == nextNode) {
        head = newNode;
        return;
    }

    node* temp = head;
    while (temp != nullptr && temp->next != nextNode) {
        temp = temp->next;
    } 

    if (temp != nullptr) {
        temp->next = newNode;
    } else {
        cout << "Given node not found in list." << endl;
        delete newNode;  
    }
}

// Function to insert at the beginning
void insertAtBeginning(node*& head, int newData) {
    node* newNode = new node;
    newNode->data = newData;
    newNode->next = head;
    head = newNode;
}

// Function to insert at the end
void insertAtEnd(node*& head, int newData) {
    node* newNode = new node;
    newNode->data = newData;
    newNode->next = nullptr;

    if (head == nullptr) {
        head = newNode;
        return;
    }

    node* temp = head;
    while (temp->next != nullptr) {
        temp = temp->next;
    }
    temp->next = newNode;
}

// Function to delete at the beginning
void deleteAtBeginning(node*& head) {
    if (head == nullptr) {
        cout << "List is empty." << endl;
        return;
    }
    node* temp = head;
    head = head->next;
    delete temp;
}

// Function to delete at the end
void deleteAtEnd(node*& head) {
    if (head == nullptr) {
        cout << "List is empty." << endl;
        return;
    }

    node* temp = head;
    if (temp->next == nullptr) {
        delete temp;
        head = nullptr;
        return;
    }

    while (temp->next->next != nullptr) {
        temp = temp->next;
    }
    delete temp->next;
    temp->next = nullptr;
}

// Function to delete a specific node
void deleteNode(node*& head, int value) {
    if (head == nullptr) {
        cout << "List is empty." << endl;
        return;
    }

    node* temp = head;
    if (temp->data == value) {
        head = temp->next;
        delete temp;
        return;
    }

    while (temp->next != nullptr && temp->next->data != value) {
        temp = temp->next;
    }

    if (temp->next != nullptr) {
        node* delNode = temp->next;
        temp->next = temp->next->next;
        delete delNode;
    } else {
        cout << "Node with value " << value << " not found." << endl;
    }
}

// Function to print the list
void printList(node* head) {
    node* cr = head;
    while (cr != nullptr) {
        cout << cr->data  << " ";
        cr = cr->next;
    }
    cout << endl;
}


void reverseList(node*& head) {
    node* prev = nullptr;
    node* current = head;
    node* next = nullptr;

    while (current != nullptr) {
        next = current->next; // store next node
        current->next = prev; // reverse current node's pointer
        prev = current;       // move prev forward
        current = next;       // move current forward
    }

    head = prev; // reset head
}

bool hasLoop(node* head) {
    node* slow = head;
    node* fast = head;

    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;

        if (slow == fast) {
            return true; // loop found
        }
    }

    return false; // no loop
}



// Function to merge two lists
void mergeLists(node*& list1, node* list2) {
    if (list1 == nullptr) {
        list1 = list2;
        return;
    }

    node* temp = list1;
    while (temp->next != nullptr) {
        temp = temp->next;
    }
    temp->next = list2;
}

// Function to search for a value in the list
bool search(node* head, int value) {
    node* temp = head;
    while (temp != nullptr) {
        if (temp->data == value) {
            return true;
        }
        temp = temp->next;
    }
    return false;
}

// Function to copy the list
node* copyList(node* head) {
    if (head == nullptr) return nullptr;

    node* newHead = new node;
    newHead->data = head->data;
    newHead->next = nullptr;

    node* temp = head->next;
    node* cr = newHead;

    while (temp != nullptr) {
        node* newNode = new node;
        newNode->data = temp->data;
        newNode->next = nullptr;
        cr->next = newNode;
        cr = newNode;
        temp = temp->next;
    }

    return newHead;
}

int main() {
    node* head = nullptr; // No dummy head, real head starts as nullptr

    int n;
    cout << "Enter number of nodes in the list: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        node* newNode = new node;
        cout << "Enter the data of node: ";
        cin >> newNode->data;
        newNode->next = nullptr;

        insertAtEnd(head, newNode->data);
    }

    cout << "Original Linked List: ";
    printList(head);

    int choice, targetData, insertData;
    cout << "Choose insertion option (1 = Insert After, 2 = Insert Before, 3 = Insert at Beginning, 4 = Insert at End): ";
    cin >> choice;

    if (choice == 1) {
        cout << "Enter the data of the node after which to insert: ";
        cin >> targetData;
        cout << "Enter the data of the new node to insert: ";
        cin >> insertData;

        node* temp = head;
        while (temp != nullptr && temp->data != targetData) {
            temp = temp->next;
        }

        if (temp != nullptr) {
            insertAfter(temp, insertData);
        } else {
            cout << "Node with data " << targetData << " not found." << endl;
        }
    } else if (choice == 2) {
        cout << "Enter the data of the node before which to insert: ";
        cin >> targetData;
        cout << "Enter the data of the new node to insert: ";
        cin >> insertData;

        node* temp = head;
        while (temp != nullptr && temp->data != targetData) {
            temp = temp->next;
        }

        if (temp != nullptr) {
            insertBefore(head, temp, insertData);
        } else {
            cout << "Node with data " << targetData << " not found." << endl;
        }
    } else if (choice == 3) {
        cout << "Enter the data of the new node to insert at the beginning: ";
        cin >> insertData;
        insertAtBeginning(head, insertData);
    } else if (choice == 4) {
        cout << "Enter the data of the new node to insert at the end: ";
        cin >> insertData;
        insertAtEnd(head, insertData);
    }

    cout << "Updated Linked List: ";
    printList(head);

    int deleteChoice, deleteData;
    cout << "Choose delete option (1 = Delete First, 2 = Delete Last, 3 = Delete Specific Node): ";
    cin >> deleteChoice;

    if (deleteChoice == 1) {
        deleteAtBeginning(head);
    } else if (deleteChoice == 2) {
        deleteAtEnd(head);
    } else if (deleteChoice == 3) {
        cout << "Enter the value of the node to delete: ";
        cin >> deleteData;
        deleteNode(head, deleteData);
    }

    cout << "Linked List after deletion: ";
    printList(head);

    node* secondList = nullptr;
    cout << "Enter number of nodes for the second list: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        node* newNode = new node;
        cout << "Enter the data of node: ";
        cin >> newNode->data;
        newNode->next = nullptr;

        insertAtEnd(secondList, newNode->data);
    }

    mergeLists(head, secondList);
    cout << "After merging the two lists: ";
    printList(head);

    cout << "Enter value to search for: ";
    cin >> deleteData;
    if (search(head, deleteData)) {
        cout << "Element found!" << endl;
    } else {
        cout << "Element not found!" << endl;
    }

    node* copiedList = copyList(head);
    cout << "Copied List: ";
    printList(copiedList);
//Reverse the list
reverseList(head);
cout << "Reversed List: ";
printList(head);

// Check for loop
if (hasLoop(head)) {
    cout << "Loop detected in the list!" << endl;
} else {
    cout << "No loop detected in the list." << endl;
}


    return 0;
}
