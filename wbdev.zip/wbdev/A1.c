//1. Traverse the array with n elements.
// #include<stdio.h> // QUeSTION 1
// int main(){
//     int n;
//     printf("enter the value of n:");
//     scanf("%d",&n);
//     int a[n];
//     for(int i=0;i<n;i++){
//         printf("enter the value of %d element",i);
//         scanf("%d",&a[i]);
//     }
//     for(int i=0;i<n;i++){
//         printf("%d",a[i]);
//     }
//     return 0;
    
// }
// QUESTION 2 Sort the array with n elements.
// #include<stdio.h>
// int main(){
//     int n;
//     printf("enter the value of n:");
//     scanf("%d",&n);
//     int a[n];
//     for(int i=0;i<n;i++){
//         printf("enter the value of %d element",i);
//         scanf("%d",&a[i]);
//     }
//     for(int i=0;i<n;i++){
//         printf("%d\n",a[i]);
//     }

//     for(int i=0;i<n-1;i++){
//         for(int j=i+1;j<n;j++){
//             if(a[i]>a[j]){
//                 int temp=a[i];
//                 a[i]=a[j];
//                 a[j]=temp;
    
//             }
//         }
        
//     }
//     printf("sorted array is:");
//     for(int i=0;i<n;i++){
//         printf("%d",a[i]);
//     }
//     return 0;
    
// }
// QUESTION 3 Insert an element at a given INDEX
// #include <stdio.h>

// int main() {
//     int n, pos, newElement;
    
//     // Taking input for array size
//     printf("Enter the number of elements in the array: ");
//     scanf("%d", &n);

//     int a[n + 1];  // Array size increased by 1 to accommodate new element

//     // Taking input for array elements
//     printf("Enter %d elements:\n", n);
//     for (int i = 0; i < n; i++) {
//         scanf("%d", &a[i]);
//     }

//     // Taking input for new element and position
//     printf("Enter the element to insert: ");
//     scanf("%d", &newElement);
    
//     printf("Enter the position (1 to %d): ", n + 1);
//     scanf("%d", &pos);

//     // Validating position
//     if (pos < 1 || pos > n + 1) {
//         printf("Invalid position! Please enter a position between 1 and %d.\n", n + 1);
//         return 1;
//     }

//     // Shifting elements to the right
//     for (int i = n; i >= pos; i--) {
//         a[i] = a[i - 1];
//     }

//     // Insert new element at the specified position
//     a[pos - 1] = newElement;

//     // Printing updated array
//     printf("Array after insertion: ");
//     for (int i = 0; i <= n; i++) {
//         printf("%d ", a[i]);
//     }
//     printf("\n");

//     return 0;
// }
// // question 4 delete Delete an element at the user given location in arrays
// #include <stdio.h>

// int main() {
//     int n, pos;

//     // Taking input for array size
//     printf("Enter the number of elements in the array: ");
//     scanf("%d", &n);

//     int a[n];  // Declare an array of size n

//     // Taking input for array elements
//     printf("Enter %d elements:\n", n);
//     for (int i = 0; i < n; i++) {
//         scanf("%d", &a[i]);
//     }

//     // Taking input for position to delete
//     printf("Enter the position (1 to %d) of the element to delete: ", n);
//     scanf("%d", &pos);

//     // Validating position
//     if (pos < 1 || pos > n) {
//         printf("Invalid position! Please enter a position between 1 and %d.\n", n);
//         return 1;
//     }

//     // Shifting elements to the left
//     for (int i = pos - 1; i < n - 1; i++) {
//         a[i] = a[i + 1];
//     }

//     // Printing updated array
//     printf("Array after deletion: ");
//     for (int i = 0; i < n - 1; i++) {
//         printf("%d ", a[i]);
//     }
//     printf("\n");

//     return 0;
// }
// QUESTION 5 MERGE TWO ARRAYS
// #include <stdio.h>

// // Function to merge two arrays
// void mergeArrays(int arr1[], int size1, int arr2[], int size2, int merged[]) {
//     int i, j, k;
//     i = j = k = 0;

//     // Copy elements of arr1 into merged array
//     for (i = 0; i < size1; i++) {
//         merged[k++] = arr1[i];
//     }

//     // Copy elements of arr2 into merged array
//     for (j = 0; j < size2; j++) {
//         merged[k++] = arr2[j];
//     }
// }

// int main() {
//     int size1, size2;

//     // Taking input for first array
//     printf("Enter the number of elements in first array: ");
//     scanf("%d", &size1);
//     int arr1[size1];

//     printf("Enter %d elements of first array: ", size1);
//     for (int i = 0; i < size1; i++) {
//         scanf("%d", &arr1[i]);
//     }

//     // Taking input for second array
//     printf("Enter the number of elements in second array: ");
//     scanf("%d", &size2);
//     int arr2[size2];

//     printf("Enter %d elements of second array: ", size2);
//     for (int i = 0; i < size2; i++) {
//         scanf("%d", &arr2[i]);
//     }

//     // Merged array declaration
//     int merged[size1 + size2];

//     // Merging the arrays
//     mergeArrays(arr1, size1, arr2, size2, merged);

//     // Printing the merged array
//     printf("Merged array: ");
//     for (int i = 0; i < size1 + size2; i++) {
//         printf("%d ", merged[i]);
//     }
//     printf("\n");

//     return 0;
// }
//QUESTION 7 STUDENT DETAIL
// #include <stdio.h>

// #define SUBJECTS 5  // Number of subjects

// // Structure to store student details
// struct Student {
//     char name[50];
//     int rollno;
//     char course[50];
//     char branch[50];
//     char dept[50];
//     int marks[SUBJECTS];
//     int total;
//     char grade;
// };

// // Function to calculate total marks and grade
// void calculateResults(struct Student *s) {
//     s->total = 0;
//     for (int i = 0; i < SUBJECTS; i++) {
//         s->total += s->marks[i]; // Sum of marks
//     }

//     float percentage = (float)s->total / (SUBJECTS * 100) * 100;

//     // Assigning grades based on percentage
//     if (percentage >= 90) {
//         s->grade = 'A';
//     } else if (percentage >= 75) {
//         s->grade = 'B';
//     } else if (percentage >= 60) {
//         s->grade = 'C';
//     } else if (percentage >= 40) {
//         s->grade = 'D';
//     } else {
//         s->grade = 'F';
//     }
// }

// // Function to take student details as input
// void inputStudent(struct Student *s) {
//     printf("Enter Name: ");
//     scanf(" %[^\n]", s->name);

//     printf("Enter Roll Number: ");
//     scanf("%d", &s->rollno);

//     printf("Enter Course: ");
//     scanf(" %[^\n]", s->course);

//     printf("Enter Branch: ");
//     scanf(" %[^\n]", s->branch);

//     printf("Enter Department: ");
//     scanf(" %[^\n]", s->dept);

//     printf("Enter marks for %d subjects (out of 100):\n", SUBJECTS);
//     for (int i = 0; i < SUBJECTS; i++) {
//         printf("Subject %d: ", i + 1);
//         scanf("%d", &s->marks[i]);
//     }

//     // Calculate total and grade
//     calculateResults(s);
// }

// // Function to display student details
// void displayStudent(struct Student s) {
//     printf("\n---------------------- Student Details ----------------------\n");
//     printf("Name: %s\nRoll Number: %d\nCourse: %s\nBranch: %s\nDepartment: %s\n", 
//            s.name, s.rollno, s.course, s.branch, s.dept);

//     printf("\nMarks:\n");
//     for (int i = 0; i < SUBJECTS; i++) {
//         printf("Subject %d: %d\n", i + 1, s.marks[i]);
//     }

//     printf("\nTotal Marks: %d/%d\n", s.total, SUBJECTS * 100);
//     printf("Grade: %c\n", s.grade);
//     printf("------------------------------------------------------------\n");
// }

// int main() {
//     struct Student student;

//     // Input student details
//     inputStudent(&student);

//     // Display student details
//     displayStudent(student);

//     return 0;
// }
// QUESTION MATRIX
// #include <stdio.h>

// void add_matrices(int rows, int cols, int A[rows][cols], int B[rows][cols], int result[rows][cols]) {
//     for (int i = 0; i < rows; i++) {
//         for (int j = 0; j < cols; j++) {
//             result[i][j] = A[i][j] + B[i][j];
//         }
//     }
// }

// void multiply_matrices(int rows, int cols, int A[rows][cols], int B[rows][cols], int result[rows][cols]) {
//     for (int i = 0; i < rows; i++) {
//         for (int j = 0; j < cols; j++) {
//             result[i][j] = 0;
//             for (int k = 0; k < cols; k++) {
//                 result[i][j] += A[i][k] * B[k][j];
//             }
//         }
//     }
// }

// void transpose_matrix(int rows, int cols, int A[rows][cols], int result[cols][rows]) {
//     for (int i = 0; i < rows; i++) {
//         for (int j = 0; j < cols; j++) {
//             result[j][i] = A[i][j];
//         }
//     }
// }

// void print_matrix(int rows, int cols, int matrix[rows][cols]) {
//     for (int i = 0; i < rows; i++) {
//         for (int j = 0; j < cols; j++) {
//             printf("%d ", matrix[i][j]);
//         }
//         printf("\n");
//     }
// }

// int main() {
//     int rows = 3, cols = 3;
//     int A[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
//     int B[3][3] = {{9, 8, 7}, {6, 5, 4}, {3, 2, 1}};
//     int result[3][3];
//     int transpose[3][3];

//     printf("Matrix A:\n");
//     print_matrix(rows, cols, A);
//     printf("\nMatrix B:\n");
//     print_matrix(rows, cols, B);

//     add_matrices(rows, cols, A, B, result);
//     printf("\nAddition of A and B:\n");
//     print_matrix(rows, cols, result);

//     multiply_matrices(rows, cols, A, B, result);
//     printf("\nMultiplication of A and B:\n");
//     print_matrix(rows, cols, result);

//     transpose_matrix(rows, cols, A, transpose);
//     printf("\nTranspose of A:\n");
//     print_matrix(cols, rows, transpose);

//     return 0;
// }
// QUESTION 
#include <stdio.h>

// Function to calculate factorial using pointers
void factorial(int *n, long long *result) {
    *result = 1;
    for (int i = 1; i <= *n; i++) {
        *result *= i;
    }
}

int main() {
    int num;
    long long fact;  // To store factorial result

    // Input from user
    printf("Enter a number: ");
    scanf("%d", &num);

    // Check for negative numbers
    if (num < 0) {
        printf("Factorial is not defined for negative numbers.\n");
    } else {
        // Call function using pointers
        factorial(&num, &fact);
        printf("Factorial of %d is %lld\n", num, fact);
    }

    return 0;
}


#include <iostream>
using namespace std;

// Recursive function to solve Tower of Hanoi
void towerOfHanoi(int n, char source, char auxiliary, char destination) {
    if (n == 1) {
        cout << "Move disk 1 from " << source << " to " << destination << endl;
        return;
    }

    // Move n-1 disks from source to auxiliary
    towerOfHanoi(n - 1, source, destination, auxiliary);

    // Move the nth disk from source to destination
    cout << "Move disk " << n << " from " << source << " to " << destination << endl;

    // Move the n-1 disks from auxiliary to destination
    towerOfHanoi(n - 1, auxiliary, source, destination);
}

int main() {
    int n;

    cout << "Enter number of disks: ";
    cin >> n;

    cout << "Steps to solve Tower of Hanoi for " << n << " disks:\n";
    towerOfHanoi(n, 'A', 'B', 'C'); // A = source, B = auxiliary, C = destination

    return 0;
}
