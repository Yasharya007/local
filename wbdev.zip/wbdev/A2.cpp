//Bubble sort
// #include<iostream>
// using namespace std;

// void swap(int *x, int *y){
//     int temp=*x;
//     *x=*y;
//     *y=temp;
// }

// void bubble(int A[],int n){
//     int flag=0;
//     for(int i=0;i<n-1;i++){
//         for(int j=0;j<n-i-1;j++){
//             if(A[j]>A[j+1]){
//                 swap(&A[j],&A[j+1]);
//                 flag=1;
//             }
//         }
//         if(flag==0)break;
// }
//     }
 
// int main(){
//     int A[]={11,13,4,3,6,2,4,8,1,34},n=10;
//     bubble(A,n);
//     for(int i=0;i<n;i++){
//         cout<<A[i]<<endl;
        
//     }
//     return 0;

// }

// INSERTION SORT
// #include<iostream>
// using namespace std;

// void swap(int *x,int*y){
//     int temp = *x;
//     *x=*y;
//     *y=temp;
// }

// void insertion(int a[],int n){
//     int x;
//     for(int i=0;i<n;i++)
//     {
//         int j=i-1;
//         x=a[i];
//         while(j>-1&&a[j]>x){
//             a[j+1]=a[j];
//             j--;
//         }
//         a[j+1]=x;
//     }
// }
// int main(){
//     int a[]={11,13,4,3,6,2,4,8,1,34},n=10;
//     insertion(a,n);
//     for(int i=0;i<n;i++)
//     cout<<a[i]<<" ";
//     return 0;
// }
//SElection sort
// #include <stdio.h>
// #include<stdlib.h>
// void swap(int *x,int *y)
// {
//  int temp=*x;
//  *x=*y;
//  *y=temp;
// }
// void SelectionSort(int A[],int n)
// {
//  int i,j,k;

//  for(i=0;i<n-1;i++)
//  {
//  for(j=k=i;j<n;j++)
//  {
//  if(A[j]<A[k])
//  k=j;
//  }
//  swap(&A[i],&A[k]);
//  }
// }
// int main()
// {
//  int A[]={11,13,7,12,16,9,24,5,10,3},n=10,i;

//  SelectionSort(A,n);

//  for(i=0;i<10;i++)
//  printf("%d ",A[i]);
//  printf("\n");
//  return 0;
// }


// QUICK SORT

// #include<iostream>
// using namespace std;

// void swap(int*x,int*y){
//     int temp = *x;
//     *x=*y;
//     *y=temp;
// }

// int partition(int a[],int l, int h){
//     int pivot=a[l];
//     int i=l,j=h;
//     do
//      {
//         do{i++;}while(a[i]<=pivot);
//         do{j--;}while(a[j]>pivot);
//         if(i<j)swap(&a[i],&a[j]);
//      }
//      while(i<j);

//      swap(&a[l],&a[j]);
//      return j;
// }

// void Quicksort(int a[],int l,int h){
//     int j;
//     if(l<h)
//     {
//         j=partition(a,l,h);
//         Quicksort(a,l,j);
//         Quicksort(a,j+1,h);
//     }
// }
// int main(){
//     int a[]={11,13,4,3,6,2,4,8,1,34},n=10;
//     Quicksort(a,0,n);
//     for(int i=0;i<n;i++){
//         cout<<a[i]<<" ";

//     }
//     return 0;
// }

// MERGE SORT

#include <stdio.h>
#include<stdlib.h>

void Merge(int A[],int l,int mid,int h)
{
 int i=l,j=mid+1,k=l;
 int B[100];

 while(i<=mid && j<=h)
 {
 if(A[i]<A[j])
 B[k++]=A[i++];
 else
 B[k++]=A[j++];
 }
 for(;i<=mid;i++)
 B[k++]=A[i];
 for(;j<=h;j++)
 B[k++]=A[j];

 for(i=l;i<=h;i++)
 A[i]=B[i];
}
void MergeSort(int A[],int l,int h)
{
 int mid;
 if(l<h)
 {
 mid=(l+h)/2;
 MergeSort(A,l,mid);
 MergeSort(A,mid+1,h);
 Merge(A,l,mid,h);

 }
}
int main()
{
 int A[]={11,13,7,12,16,9,24,5,10,3},n=10,i;

 MergeSort(A,0,n);

 for(i=0;i<10;i++)
 printf("%d ",A[i]);
 printf("\n");

 return 0;
}