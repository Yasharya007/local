// Binary tree

#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
};

Node* root = nullptr; // Global root pointer

Node* createNode(int value) {
    Node* newNode = new Node;
    if (!newNode) {
        cout << "Memory error\n";
        return nullptr;
    }
    newNode->data = value;
    newNode->left = newNode->right = nullptr;
    return newNode;
}

void insert() {
    int value;
    cout << "Enter value to insert: ";
    cin >> value;

    Node* newNode = createNode(value);
    if (root == nullptr) {
        root = newNode;
        cout << "Inserted at root.\n";
        return;
    }

    Node* temp = root;
    Node* parent = nullptr;
    char choice;

    while (temp != nullptr) {
        parent = temp;
        cout << "Insert to Left or Right of " << temp->data << "? (L/R): ";
        cin >> choice;
        if (choice == 'L' || choice == 'l') {
            temp = temp->left;
        } else {
            temp = temp->right;
        }
    }

    // Attach newNode to correct side
    if (choice == 'L' || choice == 'l')
        parent->left = newNode;
    else
        parent->right = newNode;

    cout << "Inserted successfully.\n";
}

// Traversals
void preorder(Node* p) {
    if (p) {
        cout << p->data << " ";
        preorder(p->left);
        preorder(p->right);
    }
}

void inorder(Node* p) {
    if (p) {
        inorder(p->left);
        cout << p->data << " ";
        inorder(p->right);
    }
}

void postorder(Node* p) {
    if (p) {
        postorder(p->left);
        postorder(p->right);
        cout << p->data << " ";
    }
}

// Search function
bool search(Node* p, int key) {
    if (p == nullptr)
        return false;
    if (p->data == key)
        return true;
    return search(p->left, key) || search(p->right, key);
}

int main() {
    int choice;
    do {
        cout << "\nMenu:\n";
        cout << "1. Insert node\n";
        cout << "2. Preorder traversal\n";
        cout << "3. Inorder traversal\n";
        cout << "4. Postorder traversal\n";
        cout << "5. Search for an element\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            insert();
            break;
        case 2:
            cout << "Preorder traversal: ";
            preorder(root);
            cout << endl;
            break;
        case 3:
            cout << "Inorder traversal: ";
            inorder(root);
            cout << endl;
            break;
        case 4:
            cout << "Postorder traversal: ";
            postorder(root);
            cout << endl;
            break;
        case 5:
            int key;
            cout << "Enter value to search: ";
            cin >> key;
            if (search(root, key))
                cout << "Element found!\n";
            else
                cout << "Element not found!\n";
            break;
        case 6:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice, try again.\n";
        }
    } while (choice != 6);

    return 0;
}
