
// STACK USING ARRAY
#include <iostream>
using namespace std;

struct stack {
    int size;
    int top;
    int* S;
};

void create(stack* st) {
    cout << "Enter size: ";
    cin >> st->size;
    st->top = -1;
    st->S = new int[st->size]; // Changed malloc to new
}

void Display(stack st) {
    for (int i = st.top; i >= 0; i--)
        cout << st.S[i] << " ";
    cout << endl;
}

void push(stack* st, int x) {
    if (st->top == st->size - 1)
        cout << "Stack overflow\n";
    else
        st->S[++st->top] = x;
}

int pop(stack* st) {
    int x = -1;
    if (st->top == -1)
        cout << "Stack underflow\n";
    else
        x = st->S[st->top--];
    return x;
}

int peek(stack st, int index) {
    int x = -1;
    if (st.top - index + 1 < 0)
        cout << "Invalid Index\n";
    else
        x = st.S[st.top - index + 1];
    return x;
}

int isEmpty(stack st) {
    return st.top == -1;
}

int isFull(stack st) {
    return st.top == st.size - 1;
}

int stackTop(stack st) {
    if (!isEmpty(st))
        return st.S[st.top];
    return -1;
}

int main() {
    stack st;
    create(&st);

    push(&st, 10);
    push(&st, 20);
    push(&st, 30);
    push(&st, 40);
    push(&st, 50);

    push(&st, 60); // Extra push to test overflow

    cout << "\nPeek at index 1: " << peek(st, 1) << endl;
    cout << "Stack contents: ";
    Display(st);

    // Clean up memory (optional but good practice in C++)
    delete[] st.S;

    return 0;
}
// STACK USING LINKED LSIT
#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
} *top = nullptr; // global top pointer

void push(int x) {
    Node* t = new Node;

    if (t == nullptr)
        cout << "Stack is full\n";
    else {
        t->data = x;
        t->next = top;
        top = t;
    }
}

int pop() {
    Node* t;
    int x = -1;

    if (top == nullptr)
        cout << "Stack is empty\n";
    else {
        t = top;
        top = top->next;
        x = t->data;
        delete t;
    }
    return x;
}

void display() {
    Node* p = top;
    while (p != nullptr) {
        cout << p->data << " ";
        p = p->next;
    }
    cout << "\n";
}

int main() {
    push(10);
    push(20);
    push(30);
    display();
    cout << "Popped: " << pop() << endl;
    display();
    return 0;
}
