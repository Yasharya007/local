#include <iostream>
using namespace std;

// Binary Search Tree Node
struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int value) : data(value), left(nullptr), right(nullptr) {}
};

// Function to insert a node in the tree
void insert(Node*& root, int data) {
    if (root == nullptr) {
        root = new Node(data);
        return;
    }
    if (data < root->data)
        insert(root->left, data);
    else
        insert(root->right, data);
}

// Function to perform In-Order traversal
void inorder(Node* root) {
    if (root == nullptr) return;
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

// Function to perform Pre-Order traversal
void preorder(Node* root) {
    if (root == nullptr) return;
    cout << root->data << " ";
    preorder(root->left);
    preorder(root->right);
}

// Function to perform Post-Order traversal
void postorder(Node* root) {
    if (root == nullptr) return;
    postorder(root->left);
    postorder(root->right);
    cout << root->data << " ";
}

// Function to search for a value in the tree
bool search(Node* root, int value) {
    if (root == nullptr)
        return false;
    if (root->data == value)
        return true;
    else if (value < root->data)
        return search(root->left, value);
    else
        return search(root->right, value);
}

int main() {
    Node* root = nullptr; // Start with an empty tree
    int choice, data;

    while (true) {
        cout << "\nBinary Search Tree Operations\n";
        cout << "1. Insert a node\n";
        cout << "2. In-Order Traversal\n";
        cout << "3. Pre-Order Traversal\n";
        cout << "4. Post-Order Traversal\n";
        cout << "5. Search for an element\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter data to insert: ";
                cin >> data;
                insert(root, data);
                break;

            case 2:
                cout << "In-Order Traversal: ";
                inorder(root);
                cout << endl;
                break;

            case 3:
                cout << "Pre-Order Traversal: ";
                preorder(root);
                cout << endl;
                break;

            case 4:
                cout << "Post-Order Traversal: ";
                postorder(root);
                cout << endl;
                break;

            case 5:
                cout << "Enter value to search: ";
                cin >> data;
                if (search(root, data))
                    cout << "Element found in the tree.\n";
                else
                    cout << "Element not found in the tree.\n";
                break;

            case 0:
                cout << "Exiting...\n";
                return 0;

            default:
                cout << "Invalid choice! Please try again.\n";
        }
    }

    return 0;
}
