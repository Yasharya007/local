// doubly linkedlist
// #include <iostream>
// using namespace std;

// struct Node {
//     int data;
//     Node* prev;
//     Node* next;
// };

// void insertAtBeginning(Node*& head, int data) {
//     Node* newNode = new Node{data, nullptr, head};
//     if (head != nullptr)
//         head->prev = newNode;
//     head = newNode;
// }

// void insertAtEnd(Node*& head, int data) {
//     Node* newNode = new Node{data, nullptr, nullptr};
//     if (head == nullptr) {
//         head = newNode;
//         return;
//     }
//     Node* temp = head;
//     while (temp->next != nullptr)
//         temp = temp->next;
//     temp->next = newNode;
//     newNode->prev = temp;
// }

// void insertAfter(Node* prevNode, int data) {
//     if (prevNode == nullptr) {
//         cout << "Previous node cannot be NULL\n";
//         return;
//     }
//     Node* newNode = new Node{data, prevNode, prevNode->next};
//     if (prevNode->next)
//         prevNode->next->prev = newNode;
//     prevNode->next = newNode;
// }

// void insertBefore(Node*& head, Node* nextNode, int data) {
//     if (nextNode == nullptr) {
//         cout << "Next node cannot be NULL\n";
//         return;
//     }
//     Node* newNode = new Node{data, nullptr, nextNode};
//     newNode->prev = nextNode->prev;
//     if (nextNode->prev)
//         nextNode->prev->next = newNode;
//     else
//         head = newNode;
//     nextNode->prev = newNode;
// }

// void deleteAtBeginning(Node*& head) {
//     if (head == nullptr) return;
//     Node* temp = head;
//     head = head->next;
//     if (head) head->prev = nullptr;
//     delete temp;
// }

// void deleteAtEnd(Node*& head) {
//     if (head == nullptr) return;
//     Node* temp = head;
//     while (temp->next != nullptr)
//         temp = temp->next;
//     if (temp->prev)
//         temp->prev->next = nullptr;
//     else
//         head = nullptr;
//     delete temp;
// }

// void deleteNode(Node*& head, int data) {
//     Node* temp = head;
//     while (temp != nullptr && temp->data != data)
//         temp = temp->next;
//     if (temp == nullptr) return;
//     if (temp->prev)
//         temp->prev->next = temp->next;
//     else
//         head = temp->next;
//     if (temp->next)
//         temp->next->prev = temp->prev;
//     delete temp;
// }

// void printList(Node* head) {
//     Node* temp = head;
//     while (temp) {
//         cout << temp->data << " ";
//         temp = temp->next;
//     }
//     cout << endl;
// }

// void mergeLists(Node*& list1, Node* list2) {
//     if (!list1) {
//         list1 = list2;
//         return;
//     }
//     Node* temp = list1;
//     while (temp->next)
//         temp = temp->next;
//     temp->next = list2;
//     if (list2)
//         list2->prev = temp;
// }

// bool search(Node* head, int value) {
//     Node* temp = head;
//     while (temp) {
//         if (temp->data == value)
//             return true;
//         temp = temp->next;
//     }
//     return false;
// }

// int main() {
//     Node* head = nullptr;
//     int n, data;

//     cout << "Enter number of elements in list: ";
//     cin >> n;
//     for (int i = 0; i < n; ++i) {
//         cout << "Enter data: ";
//         cin >> data;
//         insertAtEnd(head, data);
//     }

//     cout << "List: ";
//     printList(head);

//     cout << "Insert at beginning: ";
//     cin >> data;
//     insertAtBeginning(head, data);
//     printList(head);

//     cout << "Insert at end: ";
//     cin >> data;
//     insertAtEnd(head, data);
//     printList(head);

//     cout << "Insert after node with data: ";
//     int afterData;
//     cin >> afterData >> data;
//     Node* temp = head;
//     while (temp && temp->data != afterData)
//         temp = temp->next;
//     insertAfter(temp, data);
//     printList(head);

//     cout << "Insert before node with data: ";
//     int beforeData;
//     cin >> beforeData >> data;
//     temp = head;
//     while (temp && temp->data != beforeData)
//         temp = temp->next;
//     insertBefore(head, temp, data);
//     printList(head);

//     deleteAtBeginning(head);
//     deleteAtEnd(head);
//     cout << "List after deletions at beginning and end: ";
//     printList(head);

//     cout << "Delete a node with value: ";
//     cin >> data;
//     deleteNode(head, data);
//     printList(head);

//     Node* list2 = nullptr;
//     cout << "Enter number of elements in second list: ";
//     cin >> n;
//     for (int i = 0; i < n; ++i) {
//         cout << "Enter data: ";
//         cin >> data;
//         insertAtEnd(list2, data);
//     }

//     mergeLists(head, list2);
//     cout << "Merged List: ";
//     printList(head);

//     cout << "Enter value to search: ";
//     cin >> data;
//     cout << (search(head, data) ? "Found" : "Not Found") << endl;

//     return 0;
// }

// cIRCULAR DOUBLY LINKED LIST
#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

void traverse(Node* head) {
    if (!head) {
        cout << "List is empty\n";
        return;
    }
    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);
    cout << endl;
}

void insertAtBeginning(Node*& head, int data) {
    Node* newNode = new Node{data, nullptr, nullptr};
    if (!head) {
        newNode->next = newNode->prev = newNode;
        head = newNode;
        return;
    }
    Node* last = head->prev;
    newNode->next = head;
    newNode->prev = last;
    last->next = newNode;
    head->prev = newNode;
    head = newNode;
}

void insertAtEnd(Node*& head, int data) {
    if (!head) {
        insertAtBeginning(head, data);
        return;
    }
    Node* newNode = new Node{data, nullptr, nullptr};
    Node* last = head->prev;
    newNode->next = head;
    newNode->prev = last;
    last->next = newNode;
    head->prev = newNode;
}

void insertAfter(Node* head, int afterData, int data) {
    if (!head) return;
    Node* temp = head;
    do {
        if (temp->data == afterData) {
            Node* newNode = new Node{data, temp, temp->next};
            temp->next->prev = newNode;
            temp->next = newNode;
            return;
        }
        temp = temp->next;
    } while (temp != head);
    cout << "Node with data " << afterData << " not found.\n";
}

void insertBefore(Node*& head, int beforeData, int data) {
    if (!head) return;
    Node* temp = head;
    do {
        if (temp->data == beforeData) {
            if (temp == head) {
                insertAtBeginning(head, data);
            } else {
                Node* newNode = new Node{data, temp->prev, temp};
                temp->prev->next = newNode;
                temp->prev = newNode;
            }
            return;
        }
        temp = temp->next;
    } while (temp != head);
    cout << "Node with data " << beforeData << " not found.\n";
}

void deleteAtBeginning(Node*& head) {
    if (!head) return;
    if (head->next == head) {
        delete head;
        head = nullptr;
        return;
    }
    Node* last = head->prev;
    Node* temp = head;
    head = head->next;
    last->next = head;
    head->prev = last;
    delete temp;
}

void deleteAtEnd(Node*& head) {
    if (!head) return;
    if (head->next == head) {
        delete head;
        head = nullptr;
        return;
    }
    Node* last = head->prev;
    last->prev->next = head;
    head->prev = last->prev;
    delete last;
}

void deleteNode(Node*& head, int value) {
    if (!head) return;
    Node* temp = head;
    do {
        if (temp->data == value) {
            if (temp == head) {
                deleteAtBeginning(head);
            } else {
                temp->prev->next = temp->next;
                temp->next->prev = temp->prev;
                delete temp;
            }
            return;
        }
        temp = temp->next;
    } while (temp != head);
    cout << "Node with value " << value << " not found.\n";
}

void mergeLists(Node*& head1, Node* head2) {
    if (!head2) return;
    if (!head1) {
        head1 = head2;
        return;
    }
    Node* last1 = head1->prev;
    Node* last2 = head2->prev;

    last1->next = head2;
    head2->prev = last1;
    last2->next = head1;
    head1->prev = last2;
}

bool search(Node* head, int value) {
    if (!head) return false;
    Node* temp = head;
    do {
        if (temp->data == value)
            return true;
        temp = temp->next;
    } while (temp != head);
    return false;
}

int main() {
    Node* head = nullptr;
    int n, data;

    cout << "Enter number of elements in list: ";
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cout << "Enter data: ";
        cin >> data;
        insertAtEnd(head, data);
    }

    cout << "Circular Doubly Linked List: ";
    traverse(head);

    cout << "Insert at beginning: ";
    cin >> data;
    insertAtBeginning(head, data);
    traverse(head);

    cout << "Insert at end: ";
    cin >> data;
    insertAtEnd(head, data);
    traverse(head);

    cout << "Insert after node with data (enter afterData and new data): ";
    int afterData;
    cin >> afterData >> data;
    insertAfter(head, afterData, data);
    traverse(head);

    cout << "Insert before node with data (enter beforeData and new data): ";
    int beforeData;
    cin >> beforeData >> data;
    insertBefore(head, beforeData, data);
    traverse(head);

    cout << "Delete at beginning\n";
    deleteAtBeginning(head);
    traverse(head);

    cout << "Delete at end\n";
    deleteAtEnd(head);
    traverse(head);

    cout << "Delete node with value: ";
    cin >> data;
    deleteNode(head, data);
    traverse(head);

    Node* list2 = nullptr;
    cout << "Enter number of elements in second list: ";
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cout << "Enter data: ";
        cin >> data;
        insertAtEnd(list2, data);
    }

    cout << "Second Circular Doubly Linked List: ";
    traverse(list2);

    mergeLists(head, list2);
    cout << "Merged Circular Doubly Linked List: ";
    traverse(head);

    cout << "Enter value to search: ";
    cin >> data;
    cout << (search(head, data) ? "Found" : "Not Found") << endl;

    return 0;
}
