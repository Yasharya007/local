#include <iostream>
using namespace std;

struct Node {
    int data;
    int priority;
    Node* next;
} *front = nullptr; // global front pointer

void enqueue(int x, int p) {
    Node* t = new Node;
    if (t == nullptr)
        cout << "Queue is full\n";
    else {
        t->data = x;
        t->priority = p;
        t->next = nullptr;

        // Insert node in sorted order by priority
        if (front == nullptr || p < front->priority) {
            t->next = front;
            front = t;
        } else {
            Node* q = front;
            while (q->next != nullptr && q->next->priority <= p)
                q = q->next;

            t->next = q->next;
            q->next = t;
        }
    }
}

int dequeue() {
    int x = -1;
    if (front == nullptr)
        cout << "Queue is empty\n";
    else {
        Node* t = front;
        front = front->next;
        x = t->data;
        delete t;
    }
    return x;
}

int peek() {
    if (front == nullptr) {
        cout << "Queue is empty\n";
        return -1;
    }
    return front->data;
}

bool isEmpty() {
    return front == nullptr;
}

bool isFull() {
    Node* t = new Node;
    if (t == nullptr)
        return true;
    delete t;
    return false;
}

void display() {
    Node* p = front;
    if (p == nullptr) {
        cout << "Queue is empty\n";
        return;
    }
    cout << "Data(Priority): ";
    while (p != nullptr) {
        cout << p->data << "(" << p->priority << ") ";
        p = p->next;
    }
    cout << "\n";
}

int main() {
    enqueue(30, 2);
    enqueue(10, 1);
    enqueue(50, 3);
    enqueue(20, 2);
    enqueue(40, 4);

    cout << "Priority Queue contents: ";
    display();

    cout << "Front element (Peek): " << peek() << endl;

    cout << "Dequeued: " << dequeue() << endl;

    cout << "Is queue empty? " << (isEmpty() ? "Yes" : "No") << endl;
    cout << "Is queue full? " << (isFull() ? "Yes" : "No") << endl;

    cout << "Queue contents after dequeue: ";
    display();

    return 0;
}
//USING ARRAY
#include <iostream>
using namespace std;

struct PriorityQueue {
    int size;
    int front;
    int rear;
    int* data;
    int* priority;
};

void create(PriorityQueue* pq, int sz) {
    pq->size = sz;
    pq->front = pq->rear = -1;
    pq->data = new int[sz];
    pq->priority = new int[sz];
}

void enqueue(PriorityQueue* pq, int x, int p) {
    if (pq->rear == pq->size - 1) {
        cout << "Queue is full\n";
        return;
    }

    // Find the correct position to insert
    int i;
    for (i = pq->rear; i >= 0 && pq->priority[i] > p; i--) {
        pq->data[i + 1] = pq->data[i];
        pq->priority[i + 1] = pq->priority[i];
    }

    pq->data[i + 1] = x;
    pq->priority[i + 1] = p;
    pq->rear++;

    if (pq->front == -1)
        pq->front = 0;
}

int dequeue(PriorityQueue* pq) {
    int x = -1;
    if (pq->front == -1 || pq->front > pq->rear) {
        cout << "Queue is empty\n";
    } else {
        x = pq->data[pq->front++];
    }
    return x;
}

int peek(PriorityQueue pq) {
    if (pq.front == -1 || pq.front > pq.rear) {
        cout << "Queue is empty\n";
        return -1;
    }
    return pq.data[pq.front];
}

bool isEmpty(PriorityQueue pq) {
    return pq.front == -1 || pq.front > pq.rear;
}

bool isFull(PriorityQueue pq) {
    return pq.rear == pq.size - 1;
}

void display(PriorityQueue pq) {
    if (isEmpty(pq)) {
        cout << "Queue is empty\n";
        return;
    }

    cout << "Data(Priority): ";
    for (int i = pq.front; i <= pq.rear; i++) {
        cout << pq.data[i] << "(" << pq.priority[i] << ") ";
    }
    cout << "\n";
}

int main() {
    PriorityQueue pq;
    create(&pq, 10);

    enqueue(&pq, 30, 2);
    enqueue(&pq, 10, 1);
    enqueue(&pq, 50, 3);
    enqueue(&pq, 20, 2);
    enqueue(&pq, 40, 4);

    cout << "Priority Queue contents: ";
    display(pq);

    cout << "Front element (Peek): " << peek(pq) << endl;

    cout << "Dequeued: " << dequeue(&pq) << endl;

    cout << "Is queue empty? " << (isEmpty(pq) ? "Yes" : "No") << endl;
    cout << "Is queue full? " << (isFull(pq) ? "Yes" : "No") << endl;

    cout << "Queue contents after dequeue: ";
    display(pq);

    // Clean up memory
    delete[] pq.data;
    delete[] pq.priority;

    return 0;
}
