//USING ARRAY
#include <iostream>
using namespace std;

struct stack {
    int size;
    int top;
    int* S;
};

void create(stack* st) {
    cout << "Enter size: ";
    cin >> st->size;
    st->top = -1;
    st->S = new int[st->size];
}

void Display(stack st) {
    if (st.top == -1) {
        cout << "Stack is empty\n";
        return;
    }
    for (int i = st.top; i >= 0; i--)
        cout << st.S[i] << " ";
    cout << endl;
}

void push(stack* st, int x) {
    if (st->top == st->size - 1)
        cout << "Stack overflow\n";
    else
        st->S[++st->top] = x;
}

int pop(stack* st) {
    int x = -1;
    if (st->top == -1)
        cout << "Stack underflow\n";
    else
        x = st->S[st->top--];
    return x;
}

int peek(stack st, int index) {
    int x = -1;
    if (st.top - index + 1 < 0)
        cout << "Invalid Index\n";
    else
        x = st.S[st.top - index + 1];
    return x;
}

int isEmpty(stack st) {
    return st.top == -1;
}

int isFull(stack st) {
    return st.top == st.size - 1;
}

int stackTop(stack st) {
    if (!isEmpty(st))
        return st.S[st.top];
    return -1;
}

int main() {
    stack st;
    create(&st);

    push(&st, 10);
    push(&st, 20);
    push(&st, 30);
    push(&st, 40);
    push(&st, 50);

    push(&st, 60); // Overflow test

    cout << "\nTop element: " << stackTop(st) << endl;
    cout << "Peek at index 1: " << peek(st, 3) << endl;

    cout << "Popped element: " << pop(&st) << endl;

    cout << "Is stack empty? " << (isEmpty(st) ? "Yes" : "No") << endl;
    cout << "Is stack full? " << (isFull(st) ? "Yes" : "No") << endl;

    cout << "Stack contents: ";
    Display(st);

    delete[] st.S;
    return 0;
}
// //USING LINKEDLSIT
// #include <iostream>
// using namespace std;

// struct Node {
//     int data;
//     Node* next;
// } *top = nullptr; // global top pointer

// void push(int x) {
//     Node* t = new Node;
//     if (t == nullptr)
//         cout << "Stack is full\n";
//     else {
//         t->data = x;
//         t->next = top;
//         top = t;
//     }
// }

// int pop() {
//     Node* t;
//     int x = -1;

//     if (top == nullptr)
//         cout << "Stack is empty\n";
//     else {
//         t = top;
//         top = top->next;
//         x = t->data;
//         delete t;
//     }
//     return x;
// }

// int stacktop() {
//     if (top == nullptr) {
//         cout << "Stack is empty\n";
//         return -1;
//     }
//     return top->data;
// }
// int peek(int position) {
//     Node* p = top;
//     for (int i = 1; p != nullptr && i < position; i++) {
//         p = p->next;
//     }
//     if (p != nullptr)
//         return p->data;
//     else {
//         cout << "Invalid position\n";
//         return -1;
//     }
// }

// bool isEmpty() {
//     return top == nullptr;
// }

// // For linked list based implementation, stack is never full (unless memory is exhausted)
// bool isFull() {
//     Node* t = new Node;
//     if (t == nullptr)
//         return true;
//     delete t;
//     return false;
// }

// void display() {
//     Node* p = top;
//     if (p == nullptr) {
//         cout << "Stack is empty\n";
//         return;
//     }
//     while (p != nullptr) {
//         cout << p->data << " ";
//         p = p->next;
//     }
//     cout << "\n";
// }

// int main() {
//     push(10);
//     push(20);
//     push(30);
//     push(40);
//     push(50);

//     cout << "Stack contents: ";
//     display();

//     cout << "Top element (Peek): " << stacktop() << endl;
//     cout << "Element at position 2: " << peek(2) << endl;
//     cout << "Element at position 4: " << peek(4) << endl;
//     cout << "Element at position 7: " << peek(7) << endl;  // Might print invalid if stack smaller

//     cout << "Popped: " << pop() << endl;

//     cout << "Is stack empty? " << (isEmpty() ? "Yes" : "No") << endl;
//     cout << "Is stack full? " << (isFull() ? "Yes" : "No") << endl;

//     cout << "Stack contents after pop: ";
//     display();

//     return 0;
// }

// QUEUE USING ARRAY 
// #include <iostream>
// using namespace std;

// struct queue {
//     int size;
//     int front;
//     int rear;
//     int* Q;
// };

// void create(queue* q) {
//     cout << "Enter size: ";
//     cin >> q->size;
//     q->front = q->rear = -1;
//     q->Q = new int[q->size];
// }

// void enqueue(queue* q, int x) {
//     if (q->rear == q->size - 1)
//         cout << "Queue overflow\n";
//     else {
//         q->rear++;
//         q->Q[q->rear] = x;
//     }
// }

// int dequeue(queue* q) {
//     int x = -1;
//     if (q->front == q->rear)
//         cout << "Queue underflow\n";
//     else {
//         q->front++;
//         x = q->Q[q->front];
//     }
//     return x;
// }

// int peek1(queue q) {
//     if (q.front == q.rear) {
//         cout << "Queue is empty\n";
//         return -1;
//     }
//     return q.Q[q.front + 1];
// }
// int peek2(queue q, int index) {
//     if (q.front == q.rear) {
//         cout << "Queue is empty\n";
//         return -1;
//     }
//     if (index < 1 || (q.front + index) > q.rear) {
//         cout << "Invalid index\n";
//         return -1;
//     }
//     return q.Q[q.front + index];
// }


// int isEmpty(queue q) {
//     return q.front == q.rear;
// }

// int isFull(queue q) {
//     return q.rear == q.size - 1;
// }

// void display(queue q) {
//     if (q.front == q.rear) {
//         cout << "Queue is empty\n";
//         return;
//     }
//     for (int i = q.front + 1; i <= q.rear; i++)
//         cout << q.Q[i] << " ";
//     cout << endl;
// }

// int main() {
//     queue q;
//     create(&q);

//     enqueue(&q, 10);
//     enqueue(&q, 20);
//     enqueue(&q, 30);
//     enqueue(&q, 40);
//     enqueue(&q, 50);

//     enqueue(&q, 60); // Overflow test

  //  cout << "\nFront element (peek): " << peek1(q) << endl;
//   cout << "\nFront element (Peek at index 1): " << peek2(q, 1) << endl;
//   cout << "Element at index 2: " << peek2(q, 2) << endl;
//   cout << "Element at index 3: " << peek2(q, 3) << endl;
//     cout << "Dequeued element: " << dequeue(&q) << endl;

//     cout << "Is queue empty? " << (isEmpty(q) ? "Yes" : "No") << endl;
//     cout << "Is queue full? " << (isFull(q) ? "Yes" : "No") << endl;

//     cout << "Queue contents: ";
//     display(q);

//     delete[] q.Q;
//     return 0;
// }

// //QUEUE LINKEDLIST
// #include <iostream>
// using namespace std;

// struct Node {
//     int data;
//     Node* next;
// } *front = nullptr, *rear = nullptr; // global pointers for the queue

// void enqueue(int x) {
//     Node* t = new Node;
//     if (t == nullptr)
//         cout << "Queue is full\n";
//     else {
//         t->data = x;
//         t->next = nullptr;
//         if (front == nullptr) {
//             front = rear = t;
//         } else {
//             rear->next = t;
//             rear = t;
//         }
//     }
// }

// int dequeue() {
//     int x = -1;
//     Node* t;
//     if (front == nullptr)
//         cout << "Queue is empty\n";
//     else {
//         t = front;
//         front = front->next;
//         x = t->data;
//         delete t;
//     }
//     return x;
// }

// int peek1() {               //only 1st element of queue
//     if (front == nullptr) {
//         cout << "Queue is empty\n";
//         return -1;
//     }
//     return front->data;
// }
// int peek2(int index) {
//     if (front == nullptr) {
//         cout << "Queue is empty\n";
//         return -1;
//     }
//     Node* p = front;
//     for (int i = 1; p != nullptr && i < index; i++) {
//         p = p->next;
//     }
//     if (p != nullptr)
//         return p->data;
//     else {
//         cout << "Invalid index\n";
//         return -1;
//     }
// }


// bool isEmpty() {
//     return front == nullptr;
// }

// bool isFull() {
//     Node* t = new Node;
//     if (t == nullptr)
//         return true;
//     delete t;
//     return false;
// }

// void display() {
//     Node* p = front;
//     if (p == nullptr) {
//         cout << "Queue is empty\n";
//         return;
//     }
//     while (p != nullptr) {
//         cout << p->data << " ";
//         p = p->next;
//     }
//     cout << "\n";
// }

// int main() {
//     enqueue(10);
//     enqueue(20);
//     enqueue(30);
//     enqueue(40);
//     enqueue(50);

//     cout << "Queue contents: ";
//     display();

//     cout << "Front element (Peek): " << peek1() << endl;
//      cout << "Element at position 1: " << peek2(1) << endl;  // Front element
// cout << "Element at position 2: " << peek2(2) << endl;  // Next element
// cout << "Element at position 3: " << peek2(3) << endl;  // And so on

//     cout << "Dequeued: " << dequeue() << endl;

//     cout << "Is queue empty? " << (isEmpty() ? "Yes" : "No") << endl;
//     cout << "Is queue full? " << (isFull() ? "Yes" : "No") << endl;

//     cout << "Queue contents after dequeue: ";
//     display();

//     return 0;
// }
 