#include <iostream>
#include <algorithm>
using namespace std;

// AVL Tree Node
struct Node {
    int data;
    Node* left;
    Node* right;
    int height;

    Node(int value) : data(value), left(nullptr), right(nullptr), height(1) {}
};

// Get the height of the tree
int height(Node* root) {
    if (root == nullptr)
        return 0;
    return root->height;
}

// Get the balance factor of the node
int balanceFactor(Node* root) {
    if (root == nullptr)
        return 0;
    return height(root->left) - height(root->right);
}

// Update the height of the node
void updateHeight(Node* root) {
    if (root)
        root->height = max(height(root->left), height(root->right)) + 1;
}

// Right rotation (used to balance left-heavy trees)
Node* rightRotate(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;

    // Perform rotation
    x->right = y;
    y->left = T2;

    // Update heights
    updateHeight(y);
    updateHeight(x);

    // Return new root
    return x;
}

// Left rotation (used to balance right-heavy trees)
Node* leftRotate(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;

    // Perform rotation
    y->left = x;
    x->right = T2;

    // Update heights
    updateHeight(x);
    updateHeight(y);

    // Return new root
    return y;
}

// Insert a node into the AVL tree
Node* insert(Node* root, int data) {
    // 1. Perform the normal BST insert
    if (root == nullptr)
        return new Node(data);

    if (data < root->data)
        root->left = insert(root->left, data);
    else if (data > root->data)
        root->right = insert(root->right, data);
    else
        return root;  // No duplicate values allowed

    // 2. Update height of this ancestor node
    updateHeight(root);

    // 3. Get the balance factor of this node (to check whether it became unbalanced)
    int balance = balanceFactor(root);

    // If this node becomes unbalanced, then there are 4 cases

    // Left Left Case
    if (balance > 1 && data < root->left->data)
        return rightRotate(root);

    // Right Right Case
    if (balance < -1 && data > root->right->data)
        return leftRotate(root);

    // Left Right Case
    if (balance > 1 && data > root->left->data) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    // Right Left Case
    if (balance < -1 && data < root->right->data) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

// Pre-Order traversal
void preorder(Node* root) {
    if (root == nullptr) return;
    cout << root->data << " ";
    preorder(root->left);
    preorder(root->right);
}

// In-Order traversal
void inorder(Node* root) {
    if (root == nullptr) return;
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

// Post-Order traversal
void postorder(Node* root) {
    if (root == nullptr) return;
    postorder(root->left);
    postorder(root->right);
    cout << root->data << " ";
}

// Search for a value in the AVL tree
bool search(Node* root, int value) {
    if (root == nullptr)
        return false;

    if (root->data == value)
        return true;
    else if (value < root->data)
        return search(root->left, value);
    else
        return search(root->right, value);
}

int main() {
    Node* root = nullptr; // Start with an empty tree
    int choice, data;

    while (true) {
        cout << "\nAVL Tree Operations\n";
        cout << "1. Insert a node\n";
        cout << "2. In-Order Traversal\n";
        cout << "3. Pre-Order Traversal\n";
        cout << "4. Post-Order Traversal\n";
        cout << "5. Search for an element\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter data to insert: ";
                cin >> data;
                root = insert(root, data);
                break;

            case 2:
                cout << "In-Order Traversal: ";
                inorder(root);
                cout << endl;
                break;

            case 3:
                cout << "Pre-Order Traversal: ";
                preorder(root);
                cout << endl;
                break;

            case 4:
                cout << "Post-Order Traversal: ";
                postorder(root);
                cout << endl;
                break;

            case 5:
                cout << "Enter value to search: ";
                cin >> data;
                if (search(root, data))
                    cout << "Element found in the tree.\n";
                else
                    cout << "Element not found in the tree.\n";
                break;

            case 0:
                cout << "Exiting...\n";
                return 0;

            default:
                cout << "Invalid choice! Please try again.\n";
        }
    }

    return 0;
}
