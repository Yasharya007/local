#include<iostream>
using namespace std;

struct node {
    int data;
    node* prev;
    node* next;
};

// Function to create and insert at the end (used for initial list creation)
void insertAtEnd(node*& head, node*& tail, int data) {
    node* newNode = new node{data, nullptr, nullptr};
    if (!head) {
        head = tail = newNode;
    } else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
}

// Function to insert at the beginning
void insertAtBeginning(node*& head, int data) {
    node* newNode = new node{data, nullptr, head};
    if (head) {
        head->prev = newNode;
    }
    head = newNode;
}

// Function to insert after a specific node
void insertAfter(node* target, int data) {
    if (!target) return;

    node* newNode = new node{data, target, target->next};
    if (target->next) {
        target->next->prev = newNode;
    }
    target->next = newNode;
}

// Function to insert before a specific node
void insertBefore(node*& head, node* target, int data) {
    if (!target) return;
    if (target == head) {
        insertAtBeginning(head, data);
        return;
    }

    node* newNode = new node{data, target->prev, target};
    target->prev->next = newNode;
    target->prev = newNode;
}

// Function to delete from beginning
void deleteAtBeginning(node*& head) {
    if (!head) return;
    node* temp = head;
    head = head->next;
    if (head) head->prev = nullptr;
    delete temp;
}

// Function to delete from end
void deleteAtEnd(node*& tail) {
    if (!tail) return;
    node* temp = tail;
    tail = tail->prev;
    if (tail) tail->next = nullptr;
    delete temp;
}

// Function to delete a specific node
void deleteNode(node*& head, node*& tail, int data) {
    node* temp = head;
    while (temp && temp->data != data) {
        temp = temp->next;
    }
    if (!temp) {
        cout << "Node not found.\n";
        return;
    }
    if (temp == head) {
        deleteAtBeginning(head);
        if (!head) tail = nullptr;
    } else if (temp == tail) {
        deleteAtEnd(tail);
        if (!tail) head = nullptr;
    } else {
        temp->prev->next = temp->next;
        temp->next->prev = temp->prev;
        delete temp;
    }
}

// Function to print the list
void printList(node* head) {
    while (head) {
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

// Function to search for an element
bool search(node* head, int value) {
    while (head) {
        if (head->data == value) return true;
        head = head->next;
    }
    return false;
}

// Function to merge two doubly linked lists
void mergeLists(node*& head1, node*& tail1, node* head2) {
    if (!head1) {
        head1 = head2;
        return;
    }
    if (!head2) return;

    tail1->next = head2;
    head2->prev = tail1;

    while (tail1->next) {
        tail1 = tail1->next;
    }
}

int main() {
    node *head1 = nullptr, *tail1 = nullptr;
    int n, val;

    cout << "Enter number of nodes for first list: ";
    cin >> n;
    cout << "Enter values:\n";
    for (int i = 0; i < n; i++) {
        cin >> val;
        insertAtEnd(head1, tail1, val);
    }

    cout << "Original List: ";
    printList(head1);

    // Insertion options
    int choice, target;
    cout << "Insertion:\n1. Beginning\n2. End\n3. After node\n4. Before node\nEnter choice: ";
    cin >> choice;
    cout << "Enter data to insert: ";
    cin >> val;

    switch (choice) {
        case 1:
            insertAtBeginning(head1, val);
            break;
        case 2:
            insertAtEnd(head1, tail1, val);
            break;
        case 3:
            cout << "Enter target node data to insert after: ";
            cin >> target;
            {
                node* temp = head1;
                while (temp && temp->data != target) temp = temp->next;
                insertAfter(temp, val);
            }
            break;
        case 4:
            cout << "Enter target node data to insert before: ";
            cin >> target;
            {
                node* temp = head1;
                while (temp && temp->data != target) temp = temp->next;
                insertBefore(head1, temp, val);
            }
            break;
    }

    cout << "After Insertion: ";
    printList(head1);

    // Deletion options
    cout << "Deletion:\n1. Beginning\n2. End\n3. Specific node\nEnter choice: ";
    cin >> choice;
    switch (choice) {
        case 1:
            deleteAtBeginning(head1);
            if (!head1) tail1 = nullptr;
            break;
        case 2:
            deleteAtEnd(tail1);
            if (!tail1) head1 = nullptr;
            break;
        case 3:
            cout << "Enter value to delete: ";
            cin >> val;
            deleteNode(head1, tail1, val);
            break;
    }

    cout << "After Deletion: ";
    printList(head1);

    // Second list
    node *head2 = nullptr, *tail2 = nullptr;
    cout << "Enter number of nodes for second list: ";
    cin >> n;
    cout << "Enter values:\n";
    for (int i = 0; i < n; i++) {
        cin >> val;
        insertAtEnd(head2, tail2, val);
    }

    mergeLists(head1, tail1, head2);
    cout << "After Merging: ";
    printList(head1);

    cout << "Enter value to search: ";
    cin >> val;
    if (search(head1, val)) {
        cout << "Element found.\n";
    } else {
        cout << "Element not found.\n";
    }

    return 0;
}
// doubly circular

#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
};

// Function to traverse the list
void traverse(Node* head) {
    if (!head) {
        cout << "List is empty.\n";
        return;
    }

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);
    cout << endl;
}

// Insert at beginning
void insertAtBeginning(Node*& head, int data) {
    Node* newNode = new Node{data, nullptr, nullptr};
    if (!head) {
        newNode->next = newNode->prev = newNode;
        head = newNode;
        return;
    }
    Node* tail = head->prev;

    newNode->next = head;
    newNode->prev = tail;

    tail->next = newNode;
    head->prev = newNode;
    head = newNode;
}

// Insert at end
void insertAtEnd(Node*& head, int data) {
    if (!head) {
        insertAtBeginning(head, data);
        return;
    }
    Node* newNode = new Node{data, head, head->prev};
    head->prev->next = newNode;
    head->prev = newNode;
}

// Insert after a node with specific value
void insertAfter(Node* head, int afterValue, int data) {
    Node* temp = head;
    do {
        if (temp->data == afterValue) {
            Node* newNode = new Node{data, temp->next, temp};
            temp->next->prev = newNode;
            temp->next = newNode;
            return;
        }
        temp = temp->next;
    } while (temp != head);
    cout << "Node with value " << afterValue << " not found.\n";
}

// Insert before a node with specific value
void insertBefore(Node*& head, int beforeValue, int data) {
    Node* temp = head;
    do {
        if (temp->data == beforeValue) {
            if (temp == head) {
                insertAtBeginning(head, data);
            } else {
                Node* newNode = new Node{data, temp, temp->prev};
                temp->prev->next = newNode;
                temp->prev = newNode;
            }
            return;
        }
        temp = temp->next;
    } while (temp != head);
    cout << "Node with value " << beforeValue << " not found.\n";
}

// Delete at beginning
void deleteAtBeginning(Node*& head) {
    if (!head) {
        cout << "List is empty.\n";
        return;
    }

    if (head->next == head) {
        delete head;
        head = nullptr;
        return;
    }

    Node* tail = head->prev;
    Node* temp = head;
    head = head->next;

    tail->next = head;
    head->prev = tail;
    delete temp;
}

// Delete at end
void deleteAtEnd(Node*& head) {
    if (!head) {
        cout << "List is empty.\n";
        return;
    }

    if (head->next == head) {
        delete head;
        head = nullptr;
        return;
    }

    Node* last = head->prev;
    last->prev->next = head;
    head->prev = last->prev;
    delete last;
}

// Delete a node with a specific value
void deleteNode(Node*& head, int value) {
    if (!head) {
        cout << "List is empty.\n";
        return;
    }

    Node* temp = head;
    do {
        if (temp->data == value) {
            if (temp->next == temp) {
                delete temp;
                head = nullptr;
            } else {
                temp->prev->next = temp->next;
                temp->next->prev = temp->prev;
                if (temp == head) {
                    head = temp->next;
                }
                delete temp;
            }
            return;
        }
        temp = temp->next;
    } while (temp != head);
    cout << "Node with value " << value << " not found.\n";
}

// Merge two circular doubly linked lists
void mergeLists(Node*& head1, Node* head2) {
    if (!head2) return;
    if (!head1) {
        head1 = head2;
        return;
    }

    Node* tail1 = head1->prev;
    Node* tail2 = head2->prev;

    tail1->next = head2;
    head2->prev = tail1;

    tail2->next = head1;
    head1->prev = tail2;
}

// Search for an element
bool search(Node* head, int value) {
    if (!head) return false;

    Node* temp = head;
    do {
        if (temp->data == value)
            return true;
        temp = temp->next;
    } while (temp != head);

    return false;
}

int main() {
    Node* head = nullptr;
    int n, val;

    cout << "Enter number of elements: ";
    cin >> n;

    cout << "Enter elements: ";
    for (int i = 0; i < n; ++i) {
        cin >> val;
        insertAtEnd(head, val);
    }

    cout << "List: ";
    traverse(head);

    // Insertions
    insertAtBeginning(head, 100);
    insertAtEnd(head, 200);
    insertAfter(head, val, 300);  // after last input
    insertBefore(head, val, 400); // before last input

    cout << "List after insertions: ";
    traverse(head);

    // Deletions
    deleteAtBeginning(head);
    deleteAtEnd(head);
    deleteNode(head, val);

    cout << "List after deletions: ";
    traverse(head);

    // Merge
    Node* head2 = nullptr;
    cout << "Enter number of elements in second list: ";
    cin >> n;
    cout << "Enter elements: ";
    for (int i = 0; i < n; ++i) {
        cin >> val;
        insertAtEnd(head2, val);
    }

    mergeLists(head, head2);
    cout << "Merged List: ";
    traverse(head);

    // Search
    cout << "Enter value to search: ";
    cin >> val;
    if (search(head, val))
        cout << "Element found.\n";
    else
        cout << "Element not found.\n";

    return 0;
}
